// Yueqiao Zhang
// yzhan79
// Hejia Su
// hesu

#include <assert.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bitset>

using namespace std;

#include "astree.h"
#include "stringset.h"
#include "lyutils.h"
#include "symtable.h"

astree::astree (int symbol, int filenr, int linenr,
    int offset, const char* clexinfo) {
    this->symbol = symbol;
    this->filenr = filenr;
    this->linenr = linenr;
    this->offset = offset;
    this->lexinfo = intern_stringset(clexinfo);

    // asg4
    this->attributes = 0;
    this->block_nr = 0;
    this->parent = nullptr;
    this->sym = nullptr;

    // asg5
    this->emit_code = nullptr;

    DEBUGF ('f', "astree %p->{%d:%d.%d: %s: \"%s\"}\n",
            (void*) this, filenr, linenr, offset,
            get_yytname (symbol), lexinfo->c_str());
}

astree* adopt1 (astree* root, astree* child) {
    root->children.push_back (child);
    DEBUGF ('a', "%p (%s) adopting %p (%s)\n",
            root, root->lexinfo->c_str(),
            child, child->lexinfo->c_str());
    // asg4 filed
    child->parent = root;
    return root;
}

astree* adopt2 (astree* root, astree* left, astree* right) {
    adopt1 (root, left);
    adopt1 (root, right);
    return root;
}

static void dump_node (FILE* outfile, astree* node) {
    fprintf (outfile, "%p->{%s(%d) %ld:%ld.%03ld \"%s\" [",
            node, get_yytname (node->symbol), node->symbol,
            node->filenr, node->linenr, node->offset,
            node->lexinfo->c_str());
    bool need_space = false;
    for (size_t child = 0; child < node->children.size();
            ++child) {
        if (need_space) fprintf (outfile, " ");
        need_space = true;
        fprintf (outfile, "%p", node->children.at(child));
    }
    fprintf (outfile, "]}");
}

static void dump_astree_rec (FILE* outfile, astree* root,
        int depth) {
    if (root == NULL) return;

    for(int i=0; i<depth; ++i) {
        fprintf (outfile, "|  ");
    }

    const char* token = get_yytname(root->symbol);
    // int length = strlen(token);
    char tokencp[6] = "";
    for(int i=0; i<4; i++) {
        tokencp[i] = token[i];
    }
    // compare token with TOK
    if(strcmp(tokencp, "TOK_") == 0) {
        token += 4;
    }
    fprintf(outfile, "%s \"%s\" %ld.%ld.%d", token,
            root->lexinfo->c_str(), root->filenr, root->linenr,
            int(root->offset));

    fprintf(outfile, "\n");
    for (size_t child = 0; child < root->children.size();
            ++child) {
        dump_astree_rec (outfile, root->children[child],
                depth + 1);
    }
}

void dump_astree (FILE* outfile, astree* root) {
    dump_astree_rec (outfile, root, 0);
    fflush (NULL);
}

void yyprint (FILE* outfile, unsigned short toknum,
        astree* yyvaluep) {
    if (is_defined_token (toknum)) {
        dump_node (outfile, yyvaluep);
    }else {
        fprintf (outfile, "%s(%d)\n",
                get_yytname (toknum), toknum);
    }
    fflush (NULL);
}

void free_ast (astree* root) {
    while (not root->children.empty()) {
        astree* child = root->children.back();
        root->children.pop_back();
        free_ast (child);
    }
    DEBUGF ('f', "free [%p]-> %d:%d.%d: %s: \"%s\")\n",
            root, root->filenr, root->linenr, root->offset,
            get_yytname (root->symbol), root->lexinfo->c_str());
    delete root;
}

void free_ast2 (astree* tree1, astree* tree2) {
    free_ast (tree1);
    free_ast (tree2);
}

// substitude node token code and return new node
astree* convert(astree* node, int symbol) {
    node->symbol = symbol;
    return node;
}
// append 3 children to vector of children.
astree* adopt3(astree* root, astree* left, astree* mid, astree* right) {
    adopt1(root, left);
    adopt1(root, mid);
    adopt1(root, right);
    return root;
}
// substitude root token code and return root
astree* adopt_sym(astree* root, astree* child, int symbol) {
    root = adopt1(root, child);
    root->symbol = symbol;
    return root;
}

// Recusively free three astrees.
void free_ast3 (astree* tree1, astree* tree2, astree* tree3) {
    free_ast(tree1);
    free_ast(tree2);
    free_ast(tree3);
}

// Create a new astree that has 3 vector nodes
astree* create_astree(int symbol, astree* right, astree* mid,
        astree* left) {
    astree* root = new astree(symbol, left->filenr, left->linenr,
            left->offset, left->lexinfo->c_str());
    adopt2(root, right, mid);
    adopt1(root, left);
    return root;
}

attr_bitset get_attrs(astree *node) {
    switch (node->symbol) {
        case TOK_DECLID: case TOK_IDENT:
        case TOK_TYPEID: case TOK_FIELD:
            if (node->sym) return node->sym->attributes;
        default:
            return node->attributes;
    }
}

//RCSC("$Id: astree.cpp,v 1.6 2015-04-09 19:31:47-07 - - $")

