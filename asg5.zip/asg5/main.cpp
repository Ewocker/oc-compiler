// Yueqiao Zhang
// yzhan79
// Hejia Su
// hesu

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <bitset>
#include <vector>

#include "auxlib.h"
#include "stringset.h"
#include "astree.h"
#include "symtable.h"
#include "symstack.h"
#include "table_manager.h"
#include "lyutils.h"
#include "emitter.h"

#include <string>
#include <string.h>
using namespace std;

#include <errno.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

const string cpp_name = "/usr/bin/cpp";

string cpp_command;

FILE *tok;
FILE *sym;
FILE *oil;

unsigned errors;

// asg2 read the pipe from cpp
void cpp_popen() {
    // FILE *yyin is used to read the pipe from cpp
    yyin = popen (cpp_command.c_str(), "r");

    if (yyin == NULL) {
        fprintf(stderr, "This file cannot be accessed. Try another.\n");
        syserrprintf (cpp_command.c_str());
        exit(EXIT_FAILURE);
    }else {
        if (yy_flex_debug) {
            fprintf (stderr, "-- popen (%s), fileno(yyin) = %d\n",
                    cpp_command.c_str(), fileno (yyin));
        }
        lexer_newfilename(cpp_command.c_str());
    }
}

void cpp_pclose() {
    int pclose_rc = pclose(yyin);
    eprint_status(cpp_command.c_str(), pclose_rc);
    if(pclose_rc != 0) set_exitstatus(EXIT_FAILURE);
}

int main(int argc, char **argv) {
    errors = 0;

    set_execname (argv[0]);

    /* reading in --------------*/
    // read in .oc with options
    // analyze argv array set up option flags ---getopt(3)
    // -l -y -@flags -Dstring program.oc
    string d_string;
    int opt;
    yy_flex_debug = 0;

    while ((opt = getopt(argc, argv, "l@:yD:")) != -1) {
        switch(opt) {
            case 'l':
                yy_flex_debug = 1;
                break;
            case 'y':
                yydebug = 1;
                break;
            case '@':
                set_debugflags(optarg);
                break;
            case 'D':
                d_string = "-D";
                d_string = d_string + optarg + " ";
                break;
            default:
                errprintf("bad option (%c)\n", optopt);
                break;
        }
    }

    if(optind >= argc) {
        fprintf(stderr, "No arguments left to process.\n");
        exit(EXIT_FAILURE);
    }

    char* filename = argv[optind];
    char* file_basename = basename(filename);

    FILE* input = fopen(filename, "r");
    if(input == NULL) {
        fprintf(stderr, "%s does not exist.", file_basename);
        exit(EXIT_FAILURE);
    } else {
        fclose(input);
    }
    // Check if the input filename suffix is .oc
    char* ext = strrchr(filename, '.');
    if(!ext) {
        printf("This file has no extension.\n");
    } else {
        if(strcmp("oc", ext + 1) != 0) {
            fprintf(stderr, "%s does not have extension .oc.\n",
                file_basename);
            exit(EXIT_FAILURE);
        }
    }

    //Remove .oc extension and append .str to file_basename
    string file_string = filename;
    int end = file_string.find_last_of(".");
    string file_rawname = file_string.substr(0, end);
    string file_tokname = file_rawname + ".tok";
    string file_symname = file_rawname + ".sym";
    string file_oilname = file_rawname + ".oil";

    string file_astname = file_rawname + ".ast";
    file_rawname += ".str";
    string file_out = file_rawname;

    cpp_command = cpp_name + " " + d_string +  filename;
    cpp_popen();
    // open .tok file
    tok = fopen(file_tokname.c_str(), "w");

    // open .sym file
    sym = fopen(file_symname.c_str(), "w");

    // open .oil file
    oil = fopen(file_oilname.c_str(), "w");

    // parse error
    int parse_rc = yyparse();
    if (parse_rc) {
        errprintf ("parse failed (%d)\n", parse_rc);
    }

    //dump .tok file, call yylex() every time
    for(;;) {
        int token = yylex();
        if (token == YYEOF) {
            break;
        }
    }
    // close .tok file
    fclose(tok);

    //dump .str file
    FILE *out;
    out = fopen(file_out.c_str(), "w");
    dump_stringset(out);
    fclose(out);

    // dump .ast file
    FILE *ast_out;
    ast_out = fopen(file_astname.c_str(), "w");
    dump_astree(ast_out, yyparse_astree);
    fclose(ast_out);

    TableManager *manager = new TableManager(yyparse_astree, sym);
    manager->print_symtables();
    errors += manager->errors;
    delete manager;
    fclose(sym);

    // dump .oil file
    emit_everything(oil, yyparse_astree, errors);
    fclose(oil);

    cpp_pclose();
    yylex_destroy();
    free_ast(yyparse_astree);

    return EXIT_SUCCESS;
}
